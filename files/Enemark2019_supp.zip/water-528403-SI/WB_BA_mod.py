# -*- coding: utf-8 -*-
"""
Calculates a stochastic water balance based on parameter values in 
parameters_block.csv and the models defines in theta.
"""
import numpy as np
from itertools import product
import os
import time
start = time.time()

np.random.seed(1)
os.chdir('.')
out_folder='./output'
if not os.path.exists(out_folder):
    os.makedirs(out_folder)

var_cons=np.loadtxt('parameters_block.csv', delimiter=',', skiprows=1, usecols=[1,2])

nu=5 # number of uncertain components
theta=np.array(list(product([0,1],repeat=nu)))

cor=np.where((theta[:,1]==1) & (theta[:,3]==1))[0] # northern lateral discharge
# component is subtracted in both the alternative hypothesis for the northen 
# boundary and the dolostone. This should be corrected in the models in cor. 

blocksize=2048 # runs with 2048 parameter values at the time
runs=2

k=0.025 # standard deviation for relative water balance error
m=np.arange(0,len(theta))
#%%
for run in range(0,runs):
    # sample random points between 0 and 1
    a=np.random.uniform(size=[len(var_cons),blocksize]) #variables

    for i in range(0,len(var_cons)):
        #scale random points to parameter constraints in var_cons
        # (maximum-minimum)*x+minimum
        a[i,:]=(var_cons[i,1]-var_cons[i,0])*a[i,:]+var_cons[i,0]
    # calculate water balance components in C using parameter values from a
    C=np.zeros([nu,blocksize])
    #BB/C creek component
    C[0,:]=(((a[23,:]+a[25,:])*a[27,:])+(a[22,:]+a[24,:])*a[26,:])*60*60*24*365.25/2/1e6 
    #KD component
    C[1,:]=(a[3,:]*a[9 ,:]*a[5,:]+a[3,:]*a[9 ,:]*a[7,:]+ \
            a[3,:]*a[10,:]*a[6,:]+a[3,:]*a[10,:]*a[8,:])*365.25/2/1e6
    # lagoon component
    C[2,:]=(a[13,:]*(a[14,:]+a[15,:]))/1000*365.25/2/1e6 
    # Northern boundary component
    C[3,:]=(a[4,:]*a[11,:]*a[5,:]+a[3,:]*a[9 ,:]*a[5,:]+ \
            a[4,:]*a[11,:]*a[7,:]+a[3,:]*a[9 ,:]*a[7,:])*365.25/2/1e6
    # Swim creek
    C[4,:]= (a[20,:]+a[21,:])*60*60*24*365.25/2/1e6
    # constant includes the components that are with certainty in the water balance
    constant=(a[2,:]*a[1,:])/1000/1e6 \
            -(a[16,:]+a[18,:]+a[17,:]+a[19,:])*60*60*24*365.25/2/1e6 \
            -(a[4,:]*a[12,:]*a[6,:]+a[4,:]*a[12,:]*a[8,:])*365.25/2/1e6
    
    # Calculate water balance error           
    delta=constant-theta.dot(C)
    # to remove northern dolostone component if accounted for twice
    # has to be positive since it's subtracted twice
    for i in cor:
        delta[i,:]=delta[i,:]+((a[3,:]*a[9,:]*a[7,:]+a[3,:]*a[9 ,:]*a[5,:])*365.25/2/1e6)
    # Calculate relative water balance error
    delta_r=delta/((a[2,:]*a[1,:])/1000/1e6) 
    # Calculate likelihood based on relative water balance error
    li=1/k*np.exp((-(1/2*delta_r**2)/k**2))

# Metropolis-Hastings sampling on likelihood matrix
    accept=np.zeros(shape=[blocksize,1],dtype=bool)
    models=np.zeros(shape=[blocksize,1],dtype=int)
    apost=np.zeros(shape=[28,blocksize], dtype=float)
    for p in np.arange(0,blocksize): #stepping through likelihood matrix
        q=np.random.choice(m, p=li[:,p]/np.sum(li[:,p])) #choose model based on likelihood
        prop=li[q,p] # proposal likelihood
        if p==0 and run==0: #Only starts from zero if.  
            current=prop # current likelihood
        else:
            accept[p]=np.random.rand() <= prop / current
            
            if accept[p]==True: # accept new state
                current=prop  # current likelihood updated
                models[p]=q
                apost[:,p]=a[:,p]
            elif accept[p]==False: # reject and move old state forward
                apost[:,p]=apost[:,p-1]
                models[p]=models[p-1]
                    
    np.save(os.path.join(out_folder, 'accept'+str(run)+'.npy'),accept)
    np.save(os.path.join(out_folder, 'models'+str(run)+'.npy'),models)
    np.save(os.path.join(out_folder, 'vars_po'+str(run)+'.npy'),apost)
    np.save(os.path.join(out_folder, 'vars_pr'+str(run)+'.npy'),a)
    np.save(os.path.join(out_folder, 'delta_r'+str(run)+'.npy'),delta_r)
    
np.save(os.path.join(out_folder, 'runs.npy'),runs)
np.save(os.path.join(out_folder, 'blocksize.npy'),blocksize)
np.save(os.path.join(out_folder, 'variable_constraints.npy'), var_cons)

print('It took {0:0.1f} seconds'.format(time.time() - start))
del(apost)
del(a)
del(delta_r)
del(delta)
#%%
accept=np.zeros(shape=[runs*blocksize,1],dtype=bool)

for run in np.arange(0,runs):    
    accept[run*blocksize:(1+run)*blocksize]=np.load(os.path.join(out_folder, 
           'accept'+str(run)+'.npy'))
accept=np.squeeze(accept)    

models = np.zeros(shape=[runs*blocksize,1],dtype=int)   
for run in range(0,runs):    
    models[run*blocksize:(1+run)*blocksize]=np.load(os.path.join(out_folder, 
           'models'+str(run)+'.npy'))
models=np.squeeze(models)
np.save(os.path.join(out_folder, 'models_vector.npy'),models)
model_sum=np.zeros(shape=[2**nu,1],dtype=int)    

for num in range(0,2**nu):
    model_sum[num]=np.sum(models==num)
np.save(os.path.join(out_folder, 'model_sum.npy'),model_sum)

